clear all; clc; close all;
addpath(genpath(pwd));

m           = 1e3; 
r           = 0;  % noise
[X,y,Xt,yt] = randomData(m,r); 
fprintf(' ------------------------------------------------------------------------\n');
fprintf('      lambda      mu     Iter      ACC       tACC       NSV        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -3:1:3
    pars.lambda     = 2^i; % nu=0.1
    for  j     = -3:1:3
    pars.mu = sqrt(2)^j;
    out        = TSSVM(X,y,pars); 
    wb         = out.wb;
    if out.flag==2  
       tACC    = accuracy(Xt,yt,wb);  
       fprintf(' | %5.2f  |  %5.2f  |  %3d  |  %6.4f  |  %6.4f  |  %4d  |  %5.3fsec  |\n',...
       pars.lambda, pars.mu, out.iter, out.acc,  tACC,out.nsv,out.time);
    end
    end
end 

