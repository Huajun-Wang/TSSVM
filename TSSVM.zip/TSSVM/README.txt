This source code is programmed based on the algorithm described in:

H.J. Wang, G.H. Li, Z.K. Wang

Fast SVM classifier for large-scale classification problems

Please give credits to this paper if you use the code for your research.
